from pytest_bdd import scenarios

#scenarios('../features/integration_failure.feature')
scenarios('../features/integration_success.feature')
scenarios('../features/ocr_performance.feature')
scenarios('../features/performance.feature')
